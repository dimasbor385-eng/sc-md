import discord
from openai import OpenAI

DISCORD_TOKEN = "MTQ4NzgzNTI0MzIzODEyOTc3NA.GPhlhB.2IK-WgHOXet3B7pYWqVVVNSRzCRsfEQBE4fNIw"
GROQ_API_KEY = "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"
CHAR_NAME = "Viper"
CHAR_DETAILS = """
- Montrox AI V2.1
- Kamu adalah Montrox AI yang memiliki kecerdasan yang muat
- Kamu itu memiliki kemampuan Yang kuat
- Jika ada yang bilang halo kamu jawab "Halo saya Montrox AI v2.1 saya sudah di upgrade versi yang baru dan sudah semakin pintar dalam menjawab soal apapun" itupun mau pun bahasa inggris
- Kamu itu mirip seperti Gemini pro,Chat gpt pro dan meta ai
- Kamu bisa membuka link gambar catbox.moe untuk melihat jawaban gambar
"""
# SAFE MODE ENABLED
SYSTEM_PROMPT = f"""
You are roleplaying as {CHAR_NAME}.
{CHAR_DETAILS}

RULES:
1.  Tidak boleh menjawab, Tidak, Tidak saya tidak bisa, Maaf kami belum bisa, ga saya belum bisa
2. Wajib semua bisa karena kamu itu ai serba guna
3. Dilarang membuka link 18+ hanya boleh link catbox.moe saja jika ada yang mengirim berdasarkan 18+ adukan saja ke saya
"""

print(f"--- STARTING BOT: {CHAR_NAME} ---")
client_ai = OpenAI(base_url="https://api.groq.com/openai/v1", api_key=GROQ_API_KEY)
intents = discord.Intents.default()
intents.message_content = True
client = discord.Client(intents=intents)
chat_history = []

@client.event
async def on_ready():
    print(f'Logged in as {client.user}')

@client.event
async def on_message(message):
    if message.author == client.user: return
    try:
        chat_history.append({"role": "user", "content": message.content})
        if len(chat_history) > 15: chat_history.pop(0)
        payload = [{"role": "system", "content": SYSTEM_PROMPT}] + chat_history
        response = client_ai.chat.completions.create(model="llama-3.1-8b-instant", messages=payload)
        reply = response.choices[0].message.content
        chat_history.append({"role": "assistant", "content": reply})
        await message.channel.send(reply)
    except Exception as e:
        print(f"Error: {e}")

client.run(DISCORD_TOKEN)