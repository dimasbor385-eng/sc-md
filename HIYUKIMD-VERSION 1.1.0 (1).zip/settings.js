/*
    # Credits By aNdri store
  https://wa.me/6281371379077 (whatsapp) 
  https://t.me/@Androstore022 (Telegram) 
  https://whatsapp.com/channel/0029VbBBPQvD8SDsMDyM8V0v (ch wa) 
  
 NO HAPUS CREDITS!!! HARGAI PEMBUATNYA
*/
const fs = require('fs');
const chalk = require('chalk');
const { fileURLToPath, pathToFileURL } = require('url');



//settings custom pairing kode 
global.pairingKode = "HIYUKIMD" //max 8 huruf boleh huruf atau angka atau kombinasi keduanya 
//settings akses bot
global.owner = ["6281934874758"] // jangan di ubah nanti eror, cukup Lu ubah aja di owner.json

//settings info bot
global.versi = "1.1.0"
global.url = "https://tokowelperid.web.id"
global.namaOwner = "HIYUKI MD"
global.namaBot = "HIYUKI MD"
global.idCh = "120363422721110414@newsletter"
global.linkSaluran = "https://whatsapp.com/channel/0029VbBW0L5AYlUPmohzsS0Y"
global.namaSaluran = "HIYUKI INFORMASI"
global.packname = "Create by andri store"
global.author = "HIYUKI MD"

//setting pakasir
global.PROJECT_SLUG = "andri-market";   
global.API_KEY_PAKASIR = "7vT9myTxIHgjWEb1HM5d12bbcusDfTpj"; 

// anticall bot
global.anticall = {
  active: true,                 
  // SELALU AKTIF
  warningMessage: `âš ï¸ *ANTI-CALL PERMANEN AKTIF!*\n\n` +
                  `Bot ini tidak menerima panggilan telepon.\n` +
                  `Anda telah diblokir otomatis karena menelepon bot.\n` +
                  `Hubungi owner untuk membuka blokir: wa.me/6281934874758`,
  excludedNumbers: [
    "6281934874758@s.whatsapp.net",   
    // tambahkan nomor lain yang boleh telepon bot di sini
  ],
  notifyOwner: true,               
    // kirim notif ke owner setiap panggilan masuk
  ownerJid: "6281934874758@s.whatsapp.net"  // nomor owner untuk terima notif
};

global.regSession = global.regSession || new Map();

global.autoBackup = false;          // default mati dulu
global.backupInterval = null;       // simpan interval biar bisa di-clear
global.sock = null;

//thum klian
global.thumb = "https://img2.pixhost.to/images/8322/733211422_image.jpg"
global.foto = "https://img2.pixhost.to/images/8322/733211422_image.jpg"
global.menuSetting = "button" //Pilih > "docu" || "button" || "gif"
global.audioMenu = "https://c.termai.cc/v111/lKK.mpeg"

//settings cpanel 
global.loc = "1" // Isi id location
global.egg = "15" // Isi id egg
global.nestid = "5" // Isi id nest
global.domain = "https://lightsecret.zcorp.biz.id" //domain 
global.apikey = "ptla_bOqcUJ3pWvkYvZqE3pyQpO3fRC7WlLBtCAkcdwHPsnG" //plta
global.capikey = "ptlc_O3RQNkUWvm8b8yTK2lhcM9Iftixw4tFqFOGufWlA1VY" //pltc

//settings cpanelv2
global.locV2 = "1" // Isi id location
global.eggV2 = "15" // Isi id egg
global.nestidV2 = "5" // Isi id nest
global.domainV2 = "https:" //domain 
global.apikeyV2 = "ptla_" //plta
global.capikeyV2 = "ptlc_" //pltc

//=======teksPanel==========//
global.teksPanel = 
"* Expired panel 1 bulan\n* Simpan data ini sebaik mungkin\n* Garansi pembelian 20 hari (5x replace)\n* Claim garansi wajib membawa bukti chat pembelian\n* No sebar Data panel\n* No DDOS Server\n> Jika ada masalah silahkan lapor owner"


global.mess = {
 owner: "*[AKSES DITOLAK]*\nKHUSUS OWNER BOT",
 admin: "*[REJECT]* - ONLY ADMINS GROUPS",
 botAdmin: "*[REJECT]* - BOT HARUS ADMIN",
 group: "*[REJECT]* - ONLY IN THE GROUP",
 sewa: "*[REJECT]* - ONLY USER PREMIUM",
 vip: "*[REJECT]* - ONLY ONWER & PREMIUM USERS",
 private: "*[REJECT]* - ONLY IN THE PRIVATE CHAT",
 prem: "*[ Akses Ditolak ]*\nFitur ini hanya untuk user premium"
}

fs.watchFile(__filename, () => {
    fs.unwatchFile(__filename);
    console.log(chalk.white.bold("~> Update File :"), chalk.green.bold(__filename));
    delete require.cache[require.resolve(__filename)]; require(__filename);
});
global.settingMenu = "button"